import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase-admin';

export async function POST(request: Request, { params }: { params: { token: string } }) {
  const body = await request.json().catch(() => null);
  const latitude = Number(body?.latitude), longitude = Number(body?.longitude);
  const accuracy = body?.accuracy == null ? null : Number(body.accuracy);
  if (body?.consent !== true || !Number.isFinite(latitude) || latitude < -90 || latitude > 90 ||
      !Number.isFinite(longitude) || longitude < -180 || longitude > 180 ||
      (accuracy !== null && (!Number.isFinite(accuracy) || accuracy < 0))) {
    return NextResponse.json({ error: 'Dados inválidos.' }, { status: 400 });
  }
  const db = createAdminClient();
  const { data: link, error } = await db.from('location_links').select('id,status,expires_at').eq('token', params.token).maybeSingle();
  if (error || !link) return NextResponse.json({ error: 'Link inválido.' }, { status: 404 });
  if (link.status !== 'pending' || (link.expires_at && new Date(link.expires_at) < new Date()))
    return NextResponse.json({ error: 'Link expirado ou já utilizado.' }, { status: 410 });
  const capturedAt = new Date().toISOString();
  const { error: insertError } = await db.from('location_records').insert({
    link_id: link.id, latitude, longitude, accuracy, captured_at: capturedAt, consent_given: true
  });
  if (insertError) return NextResponse.json({ error: 'Não foi possível registrar. O link pode já ter sido utilizado.' }, { status: 409 });
  await db.from('location_links').update({ status: 'completed' }).eq('id', link.id);
  return NextResponse.json({ ok: true, captured_at: capturedAt });
}
