import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase-admin';
export async function GET(_: Request, { params }: { params: { token: string } }) {
  const db = createAdminClient();
  const { data, error } = await db.from('location_links').select('id,client_name,contract_label,status,expires_at').eq('token', params.token).maybeSingle();
  if (error || !data) return NextResponse.json({ error: 'Link inválido ou indisponível.' }, { status: 404 });
  if (data.status !== 'pending') return NextResponse.json({ error: 'Este link não está mais disponível.' }, { status: 410 });
  if (data.expires_at && new Date(data.expires_at) < new Date()) return NextResponse.json({ error: 'Este link expirou.' }, { status: 410 });
  return NextResponse.json(data, { headers: { 'Cache-Control': 'no-store' } });
}
