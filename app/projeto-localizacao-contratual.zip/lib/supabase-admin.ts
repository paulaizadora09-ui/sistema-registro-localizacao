import { createClient } from '@supabase/supabase-js';
export function createAdminClient() {
 const url=process.env.NEXT_PUBLIC_SUPABASE_URL, key=process.env.SUPABASE_SERVICE_ROLE_KEY;
 if(!url||!key) throw new Error('Configuração do servidor incompleta.');
 return createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
}
