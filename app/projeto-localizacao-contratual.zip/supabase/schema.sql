create extension if not exists pgcrypto;

create table if not exists public.location_links (
  id uuid primary key default gen_random_uuid(),
  client_name text not null,
  contract_label text not null,
  token text not null unique,
  status text not null default 'pending' check (status in ('pending','completed','revoked')),
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.location_records (
  id uuid primary key default gen_random_uuid(),
  link_id uuid not null unique references public.location_links(id) on delete restrict,
  latitude double precision not null check (latitude between -90 and 90),
  longitude double precision not null check (longitude between -180 and 180),
  accuracy double precision,
  captured_at timestamptz not null,
  consent_given boolean not null check (consent_given = true),
  created_at timestamptz not null default now()
);

alter table public.location_links enable row level security;
alter table public.location_records enable row level security;

-- Painel: somente usuários autenticados podem consultar/criar links.
create policy "admin select links" on public.location_links for select to authenticated using (true);
create policy "admin insert links" on public.location_links for insert to authenticated with check (true);
create policy "admin update links" on public.location_links for update to authenticated using (true) with check (true);
create policy "admin read records" on public.location_records for select to authenticated using (true);


-- A página pública acessa os links exclusivamente pelas rotas server-side do Next.js.
-- NÃO crie políticas SELECT/INSERT/UPDATE para o papel anon.
-- SUPABASE_SERVICE_ROLE_KEY fica somente no servidor.
